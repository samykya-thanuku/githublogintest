package com.cg.githublogintest.test;



import static org.testng.Assert.assertEquals;

import java.net.MalformedURLException;

import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.cg.githublogintest.model.LoginPage;
import com.cg.githublogintest.utility.BrowserCapabilitiesUtility;

public class LoginTest {
	
	public static String webURL = "http://www.github.com/login";
	public static String hubURL="http://10.102.52.216:4444/wd/hub";

	public static RemoteWebDriver driver;
	private LoginPage loginPage;

	/*@BeforeTest
	@Parameters({ "browser" })
	public void setUpGoogleChromeTestEnv(@Optional("browser") String browser) throws MalformedURLException {
		driver = BrowserCapabilitiesUtility.getDriver(hubURL,browser);
		driver.manage().window().maximize();
	}
	*/

	@BeforeMethod
	@Parameters({ "browser" })
	public void setUptestEnv(@Optional("browser") String browser) throws MalformedURLException {
		driver = BrowserCapabilitiesUtility.getDriver(hubURL,browser);
		driver.manage().window().maximize();
		driver.get("http://www.github.com/login");
		loginPage=new LoginPage();
		PageFactory.initElements(driver, loginPage);
	}

	/*@BeforeMethod
	public void setUptestEnv() {
		driver.get("http://www.github.com/login");
		loginPage=new LoginPage();
		PageFactory.initElements(driver, loginPage);
	}*/
	
	@Test(priority=1)
	public void testForBlankUserNameAndPassword() {
		loginPage.setUsername("");
		loginPage.setPassword("");
		loginPage.clickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath("//div[@class='container']")).getText();
		System.out.println("error Message:-"+actualErrorMessage);
		String message="Incorrect username or password.";
		assertEquals(actualErrorMessage, message);
	}

	@Test(priority=2)
	public void testForInValidUserNameAndValidPassword() {
		loginPage.setUsername(getInvalidUserName());
		loginPage.setPassword(getValidPassword());
		loginPage.clickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath("//div[@class='container']")).getText();
		System.out.println("error Message:-"+actualErrorMessage);
		String message="Incorrect username or password.";
		assertEquals(actualErrorMessage, message);
	}

	private String getValidPassword() {
		
		return "abhinav123";
	}

	private String getInvalidUserName() {
		
		return "ahikoti";
	}

	@Test(priority=3)
	public void testForValidUserNameAndInValidPassword() {
	
		loginPage.setUsername(getValidUserName());
		loginPage.setPassword(getInvalidPassword());
		loginPage.clickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath("//div[@class='container']")).getText();
		System.out.println("error Message:-"+actualErrorMessage);
		String message="Incorrect username or password.";
		assertEquals(actualErrorMessage, message);

	}

	private String getInvalidPassword() {
		
		return "xyz";
	}

	private String getValidUserName() {
	
		return "achikoti";
	}

	@Test(priority=4)
	public void testForInValidUserNameAndPassword() {
		
		loginPage.setUsername(getInvalidUserName());
		loginPage.setPassword(getInvalidPassword());
		loginPage.clickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath("//div[@class='container']")).getText();
		System.out.println("error Message:-"+actualErrorMessage);
		String message="Incorrect username or password.";
		assertEquals(actualErrorMessage, message);
	}

	@Test(priority=5)
	public void testForValidUserNameAndPassword() {
		loginPage.setUsername(getValidUserName());
		loginPage.setPassword(getValidPassword());
		loginPage.clickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath("//meta[@name='user-login']" )).getAttribute("content");
		System.out.println("User:-"+actualErrorMessage);
		String message="achikoti";
		assertEquals(actualErrorMessage, message);
	}
	@AfterMethod
	public void tearDowntestEnv() {
		loginPage=null;
	}

	@AfterClass
	public static void tearDownDriverEnv() {
		driver.close();
		driver=null;

	}
}
